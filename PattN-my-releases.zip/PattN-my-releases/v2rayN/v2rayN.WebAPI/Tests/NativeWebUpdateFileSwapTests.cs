using v2rayN.WebAPI.Launcher;
using System.Security.Cryptography;
using System.Text;
using System.IO.MemoryMappedFiles;

namespace v2rayN.WebAPI.Tests;

public class NativeWebUpdateFileSwapTests
{
    private static string ExecutableName => OperatingSystem.IsWindows() ? "v2rayN.WebAPI.exe" : "v2rayN.WebAPI";
    private static string Rid => OperatingSystem.IsWindows() ? "win-x64" : "linux-x64";

    [Test]
    public async Task RollbackDoesNotModifyAnExecutableThatIsStillMemoryMapped()
    {
        if (!OperatingSystem.IsLinux()) return;
        using var directory = new TemporaryDirectory();
        var plan = await CreatePlanAsync(directory.Path, includeNewIdentity: true);
        NativeWebUpdateHelper.CopyCurrentAppToBackup(plan);
        NativeWebUpdateHelper.SwapCandidateAppIntoPlace(plan);
        using var executable = new FileStream(Path.Combine(plan.InstallDirectory, ExecutableName),
            FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        using var mapping = MemoryMappedFile.CreateFromFile(executable, null, 0,
            MemoryMappedFileAccess.Read, HandleInheritability.None, leaveOpen: true);
        using var view = mapping.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
        await view.ReadByte(0).Should().BeEqualTo((byte)'n');

        NativeWebUpdateHelper.RestorePreviousApp(plan);

        await view.ReadByte(0).Should().BeEqualTo((byte)'n');
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, ExecutableName))).Should().BeEqualTo("old-web");
        await Directory.GetFiles(plan.InstallDirectory, ".v2rayn-WebAPI-restore-*").Length.Should().BeEqualTo(0);
    }

    [Test]
    public async Task ApiSelfUpdatePreservesUnrelatedFilesByteForByte()
    {
        using var directory = new TemporaryDirectory();
        var plan = await CreatePlanAsync(directory.Path, includeNewIdentity: true);
        var extraHash = await HashDirectoryAsync(Path.Combine(plan.InstallDirectory, "extra"));
        NativeWebUpdateHelper.CopyCurrentAppToBackup(plan);
        NativeWebUpdateHelper.SwapCandidateAppIntoPlace(plan);

        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, ExecutableName))).Should().BeEqualTo("new-web");
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, "extra", "marker.dat"))).Should().BeEqualTo("UNRELATED_FILE_TEST");
        await (await HashDirectoryAsync(Path.Combine(plan.InstallDirectory, "extra"))).Should().BeEqualTo(extraHash);
        await Directory.Exists(Path.Combine(plan.BackupDirectory, "extra")).Should().BeFalse();
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, "bin", "xray", "xray"))).Should().BeEqualTo("updated-core");
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, "guiConfigs", "guiNConfig.json"))).Should().BeEqualTo("user-config");
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, ".env"))).Should().BeEqualTo("V2RAYN_WEB_API_KEY=private-test-key\n");
        await File.Exists(Path.Combine(plan.BackupDirectory, ".env")).Should().BeFalse();
    }

    [Test]
    public async Task PartialFileReplacementFailureRestoresOldAppWithoutTouchingCoreFiles()
    {
        using var directory = new TemporaryDirectory();
        var plan = await CreatePlanAsync(directory.Path, includeNewIdentity: false);
        var extraHash = await HashDirectoryAsync(Path.Combine(plan.InstallDirectory, "extra"));
        NativeWebUpdateHelper.CopyCurrentAppToBackup(plan);

        var rollback = await NativeWebUpdateWorkflow.ApplyAsync(
            () => { NativeWebUpdateHelper.SwapCandidateAppIntoPlace(plan); return Task.CompletedTask; },
            () => Task.FromResult(false),
            () => { NativeWebUpdateHelper.RestorePreviousApp(plan); return Task.CompletedTask; },
            () => Task.FromResult(true),
            _ => { },
            () => Task.CompletedTask);

        await rollback.Success.Should().BeFalse();
        await rollback.RollbackSucceeded.Should().BeTrue();
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, ExecutableName))).Should().BeEqualTo("old-web");
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, "extra", "marker.dat"))).Should().BeEqualTo("UNRELATED_FILE_TEST");
        await (await HashDirectoryAsync(Path.Combine(plan.InstallDirectory, "extra"))).Should().BeEqualTo(extraHash);
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, "bin", "xray", "xray"))).Should().BeEqualTo("updated-core");
        await (await File.ReadAllTextAsync(Path.Combine(plan.InstallDirectory, ".env"))).Should().BeEqualTo("V2RAYN_WEB_API_KEY=private-test-key\n");
        await File.Exists(Path.Combine(plan.BackupDirectory, ".env")).Should().BeFalse();
    }

    private static async Task<NativeWebUpdatePlan> CreatePlanAsync(string root, bool includeNewIdentity)
    {
        var install = Path.Combine(root, "native");
        var parent = Path.GetDirectoryName(install)!;
        var candidate = Path.Combine(parent, ".v2rayn-WebAPI-candidate-test");
        var backup = Path.Combine(parent, ".v2rayn-WebAPI-backup-test");
        Directory.CreateDirectory(Path.Combine(install, "extra", "nested"));
        Directory.CreateDirectory(Path.Combine(install, "bin", "xray"));
        Directory.CreateDirectory(Path.Combine(install, "guiConfigs"));
        Directory.CreateDirectory(candidate);
        await File.WriteAllTextAsync(Path.Combine(install, ExecutableName), "old-web");
        await File.WriteAllTextAsync(Path.Combine(install, "v2rayN.WebAPI.build.json"), "old-identity");
        await File.WriteAllTextAsync(Path.Combine(install, "extra", "marker.dat"), "UNRELATED_FILE_TEST");
        await File.WriteAllTextAsync(Path.Combine(install, "extra", "nested", "test.dat"), "unrelated nested data");
        await File.WriteAllTextAsync(Path.Combine(install, "bin", "xray", "xray"), "updated-core");
        await File.WriteAllTextAsync(Path.Combine(install, "guiConfigs", "guiNConfig.json"), "user-config");
        await File.WriteAllTextAsync(Path.Combine(install, ".env"), "V2RAYN_WEB_API_KEY=private-test-key\n");
        await File.WriteAllTextAsync(Path.Combine(candidate, ExecutableName), "new-web");
        if (includeNewIdentity)
            await File.WriteAllTextAsync(Path.Combine(candidate, "v2rayN.WebAPI.build.json"), "new-identity");
        return new NativeWebUpdatePlan(
            install,
            candidate,
            backup,
            Path.Combine(root, "instance.lock"),
            "http://127.0.0.1:5080/api/health",
            [],
            "7.25.2-web.2",
            "new-commit",
            Rid,
            "7.25.2-web.1",
            Path.Combine(root, "runtime-intent.json"),
            Path.Combine(root, "update-progress.json"));
    }

    private static async Task<string> HashDirectoryAsync(string path)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        foreach (var file in Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories)
                     .Order(StringComparer.Ordinal))
        {
            hash.AppendData(Encoding.UTF8.GetBytes(Path.GetRelativePath(path, file).Replace(Path.DirectorySeparatorChar, '/')));
            hash.AppendData([0]);
            hash.AppendData(await File.ReadAllBytesAsync(file));
        }
        return Convert.ToHexString(hash.GetHashAndReset());
    }

    private sealed class TemporaryDirectory : IDisposable
    {
        public TemporaryDirectory()
        {
            Path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"v2rayn-WebAPI-swap-test-{Guid.NewGuid():N}");
            Directory.CreateDirectory(Path);
        }

        public string Path { get; }

        public void Dispose() => Directory.Delete(Path, recursive: true);
    }
}
