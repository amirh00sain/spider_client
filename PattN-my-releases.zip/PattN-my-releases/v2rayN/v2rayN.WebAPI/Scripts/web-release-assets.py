#!/usr/bin/env python3
"""Package the headless PattN Web API release ZIPs and report their asset names.

The RID-to-asset map lives in `../Assets/web-assets.json`. The Web assembly embeds the same
file, so the runtime updater, the release manifest, and this packager never disagree about the
release asset names:

  linux-x64        -> PattN-linux-64-WebAPI.zip        + PattN-linux-64-WebAPI-update.zip
  linux-arm64      -> PattN-linux-arm64-WebAPI.zip     + PattN-linux-arm64-WebAPI-update.zip
  linux-riscv64    -> PattN-linux-riscv64-WebAPI.zip   + PattN-linux-riscv64-WebAPI-update.zip
  linux-loongarch64-> PattN-linux-loong64-WebAPI.zip   + PattN-linux-loong64-WebAPI-update.zip
  win-x64          -> PattN-windows-64-WebAPI.zip      + PattN-windows-64-WebAPI-update.zip
  win-arm64        -> PattN-windows-arm64-WebAPI.zip   + PattN-windows-arm64-WebAPI-update.zip

Usage:
  web-release-assets.py get --rid linux-x64 --field full
  web-release-assets.py package --rid linux-x64 --publish publish/linux-x64 --dist dist
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import sys
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ASSET_MAP_PATH = SCRIPT_DIR.parent / "Assets" / "web-assets.json"
FIXED_TIME = (1980, 1, 1, 0, 0, 0)
BUILD_IDENTITY_NAME = "v2rayN.WebAPI.build.json"
ENVIRONMENT_FILE_NAMES = frozenset((".env", ".env.example"))
EXECUTABLE_NAMES = {
    "linux-x64": "v2rayN.WebAPI",
    "linux-arm64": "v2rayN.WebAPI",
    "linux-riscv64": "v2rayN.WebAPI",
    "linux-loongarch64": "v2rayN.WebAPI",
    "win-x64": "v2rayN.WebAPI.exe",
    "win-arm64": "v2rayN.WebAPI.exe",
}
# PattN: the Aether core and the two programs it runs, with their license texts and notice, in bin/aether, and
# Psiphon's signed server list in bin, as PattN's desktop packages bundle them (package-aether.sh). Only where
# patterniha/Aether publishes an archive: linux-riscv64 and linux-loongarch64 have none.
AETHER_TEXT_FILES = (
    "bin/aether/NOTICE.txt", "bin/aether/AGPL-3.0.txt", "bin/aether/GPL-3.0.txt", "bin/aether/lyrebird-LICENSE.txt",
    "bin/psiphon_servers.dat", "bin/psiphon_servers.stamp",
)
LINUX_AETHER_EXECUTABLES = ("bin/aether/aether", "bin/aether/lyrebird", "bin/aether/psiphon-tunnel-core")
WINDOWS_AETHER_EXECUTABLES = ("bin/aether/aether.exe", "bin/aether/lyrebird.exe", "bin/aether/psiphon-tunnel-core.exe")
AETHER_REQUIRED_EXECUTABLES = {
    "linux-x64": LINUX_AETHER_EXECUTABLES,
    "linux-arm64": LINUX_AETHER_EXECUTABLES,
    "win-x64": WINDOWS_AETHER_EXECUTABLES,
    "win-arm64": WINDOWS_AETHER_EXECUTABLES,
}
REQUIRED_FILES = {
    "linux-x64": (
        "v2rayN.WebAPI", BUILD_IDENTITY_NAME, "bin/sing_box/libcronet.so", "bin/geosite.dat",
        "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb", "bin/srss/geosite-category-ads-all.srs",
    ) + LINUX_AETHER_EXECUTABLES + AETHER_TEXT_FILES,
    "linux-arm64": (
        "v2rayN.WebAPI", BUILD_IDENTITY_NAME, "bin/sing_box/libcronet.so", "bin/geosite.dat",
        "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb", "bin/srss/geosite-category-ads-all.srs",
    ) + LINUX_AETHER_EXECUTABLES + AETHER_TEXT_FILES,
    "linux-riscv64": (
        "v2rayN.WebAPI", BUILD_IDENTITY_NAME, "bin/geosite.dat",
        "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb", "bin/srss/geosite-category-ads-all.srs",
    ),
    "linux-loongarch64": (
        "v2rayN.WebAPI", BUILD_IDENTITY_NAME, "bin/geosite.dat",
        "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb", "bin/srss/geosite-category-ads-all.srs",
    ),
    "win-x64": (
        "v2rayN.WebAPI.exe", BUILD_IDENTITY_NAME, "bin/xray/xray.exe", "bin/sing_box/sing-box.exe",
        "bin/mihomo/mihomo.exe", "bin/geosite.dat", "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb",
    ) + WINDOWS_AETHER_EXECUTABLES + AETHER_TEXT_FILES,
    "win-arm64": (
        "v2rayN.WebAPI.exe", BUILD_IDENTITY_NAME, "bin/xray/xray.exe", "bin/sing_box/sing-box.exe",
        "bin/mihomo/mihomo.exe", "bin/geosite.dat", "bin/geoip.dat", "bin/geoip.metadb", "bin/Country.mmdb",
    ) + WINDOWS_AETHER_EXECUTABLES + AETHER_TEXT_FILES,
}
LINUX_REQUIRED_EXECUTABLES = ("bin/xray/xray", "bin/sing_box/sing-box", "bin/mihomo/mihomo")
WINDOWS_REQUIRED_EXECUTABLES = (
    "v2rayN.WebAPI.exe", "bin/xray/xray.exe", "bin/sing_box/sing-box.exe", "bin/mihomo/mihomo.exe",
)
BLOCK_SIZE = 1024 * 1024


def is_windows_rid(rid: str) -> bool:
    return rid.startswith("win-")


def fail(message: str) -> None:
    print(f"web release assets error: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_assets() -> dict[str, dict[str, str]]:
    try:
        data = json.loads(ASSET_MAP_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"could not read {ASSET_MAP_PATH}: {exc}")
    if not isinstance(data, dict) or not isinstance(data.get("assets"), list):
        fail(f"{ASSET_MAP_PATH} is missing its assets list")
    assets: dict[str, dict[str, str]] = {}
    for entry in data["assets"]:
        if not isinstance(entry, dict):
            fail(f"{ASSET_MAP_PATH} contains a non-object asset entry")
        values = (entry.get("rid"), entry.get("arch"), entry.get("full"), entry.get("update"))
        if not all(isinstance(value, str) and value for value in values) or values[0] in assets:
            fail(f"{ASSET_MAP_PATH} contains an invalid or duplicate asset entry")
        assets[values[0]] = {"arch": values[1], "full": values[2], "update": values[3]}
    if not assets:
        fail(f"{ASSET_MAP_PATH} contains no assets")
    return assets


def normalize_entry(name: str) -> str:
    """Normalize an archive entry name the same way the Web runtime package stager does."""
    if not name or name.startswith("/") or "\\" in name or "\0" in name:
        fail(f"invalid archive path: {name!r}")
    segments = [segment for segment in name.split("/") if segment]
    if not segments or any(segment in (".", "..") or ":" in segment for segment in segments):
        fail(f"invalid archive path: {name!r}")
    return "/".join(segments)


def collect_tree(root: Path) -> list[tuple[str, Path, str]]:
    entries: list[tuple[str, Path, str]] = []
    for current, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        filenames.sort()
        for name in list(dirnames):
            path = Path(current) / name
            if path.is_symlink():
                entries.append((path.relative_to(root).as_posix(), path, "symlink"))
                dirnames.remove(name)
        for name in filenames:
            path = Path(current) / name
            if path.is_symlink():
                entries.append((path.relative_to(root).as_posix(), path, "symlink"))
            elif path.is_file():
                entries.append((path.relative_to(root).as_posix(), path, "file"))
            else:
                fail(f"unsupported file type in the Web package: {path}")
    return entries


def write_file(handle: zipfile.ZipFile, source: Path, arcname: str, mode: int) -> None:
    info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
    info.create_system = 3
    info.external_attr = ((stat.S_IFREG | mode) & 0xFFFF) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    with source.open("rb") as reader, handle.open(info, "w") as writer:
        shutil.copyfileobj(reader, writer, BLOCK_SIZE)


def write_symlink(handle: zipfile.ZipFile, target: str, arcname: str) -> None:
    info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
    info.create_system = 3
    info.external_attr = (stat.S_IFLNK | 0o777) << 16
    info.compress_type = zipfile.ZIP_STORED
    handle.writestr(info, target)


def create_full_zip(publish: Path, output: Path, rid: str) -> None:
    env_example = SCRIPT_DIR.parent / ".env.example"
    if env_example.is_symlink() or not env_example.is_file():
        fail(f"full package is missing the source environment example: {env_example}")

    # Only the reviewed template is shipped. A local .env (or another copied template) is
    # never taken from the publish tree, even if a build tool happened to copy it there.
    entries = [
        entry for entry in collect_tree(publish)
        if not any(segment in ENVIRONMENT_FILE_NAMES for segment in entry[0].split("/"))
    ]
    names = {relative for relative, _, _ in entries}
    for required in REQUIRED_FILES[rid]:
        if required not in names:
            fail(f"full package is missing required file: {required}")
    required_executables = WINDOWS_REQUIRED_EXECUTABLES if is_windows_rid(rid) else LINUX_REQUIRED_EXECUTABLES
    # PattN: and the Aether core with its two programs, which must run outside Windows as the other Cores
    required_executables += AETHER_REQUIRED_EXECUTABLES.get(rid, ())
    for required in required_executables:
        if required not in names or (not is_windows_rid(rid) and not os.access(publish / required, os.X_OK)):
            fail(f"full package is missing required executable: {required}")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as handle:
        for relative, path, kind in entries:
            if kind == "symlink":
                write_symlink(handle, os.readlink(path), relative)
            else:
                write_file(handle, path, relative, stat.S_IMODE(path.stat().st_mode))
        write_file(handle, env_example, ".env.example", 0o644)


def create_update_zip(publish: Path, output: Path, rid: str) -> None:
    executable_name = EXECUTABLE_NAMES[rid]
    if not (publish / executable_name).is_file() or (not is_windows_rid(rid) and not os.access(publish / executable_name, os.X_OK)):
        fail(f"app-only package is missing required executable: {executable_name}")
    entries: list[tuple[str, Path]] = []
    for name in (executable_name, BUILD_IDENTITY_NAME):
        path = publish / name
        if path.is_symlink() or not path.is_file():
            fail(f"app-only package is missing required file: {name}")
    entries.append((executable_name, publish / executable_name))
    entries.append((BUILD_IDENTITY_NAME, publish / BUILD_IDENTITY_NAME))

    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as handle:
        for arcname, path in entries:
            write_file(handle, path, arcname, stat.S_IMODE(path.stat().st_mode))
    verify_update_zip(output, rid)


def verify_update_zip(path: Path, rid: str) -> None:
    executable_name = EXECUTABLE_NAMES[rid]
    try:
        handle = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile) as exc:
        fail(f"app-only package {path.name} could not be read: {exc}")
    with handle:
        seen: set[str] = set()
        for info in handle.infolist():
            if (info.external_attr >> 16) & 0xF000 not in (0, 0x4000, 0x8000):
                fail(f"app-only package {path.name} contains a link or special entry: {info.filename}")
            name = normalize_entry(info.filename)
            if any(segment in ENVIRONMENT_FILE_NAMES for segment in name.split("/")):
                fail(f"app-only package {path.name} must not contain environment files: {name}")
            if name in seen:
                fail(f"app-only package {path.name} contains a duplicate archive path: {name}")
            seen.add(name)
            if name not in (executable_name, BUILD_IDENTITY_NAME):
                fail(f"app-only package {path.name} contains an unexpected entry: {name}")
        for required in (executable_name, BUILD_IDENTITY_NAME):
            if required not in seen:
                fail(f"app-only package {path.name} is missing {required}")


def get_command(args: argparse.Namespace) -> None:
    assets = load_assets()
    entry = assets.get(args.rid)
    if entry is None:
        fail(f"unsupported runtime identifier: {args.rid}")
    print(entry[args.field])


def package_command(args: argparse.Namespace) -> None:
    assets = load_assets()
    entry = assets.get(args.rid)
    if entry is None:
        fail(f"unsupported runtime identifier: {args.rid}")
    publish = Path(args.publish)
    dist = Path(args.dist)
    if not publish.is_dir():
        fail(f"publish directory does not exist: {publish}")
    dist.mkdir(parents=True, exist_ok=True)
    full_archive = dist / entry["full"]
    update_archive = dist / entry["update"]
    create_full_zip(publish, full_archive, args.rid)
    create_update_zip(publish, update_archive, args.rid)
    print(f"Packaged {full_archive} and {update_archive}")


def main(argv: list[str]) -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    subparsers = parser.add_subparsers(dest="command", required=True)

    get_parser = subparsers.add_parser("get", help="print a shared release asset name")
    get_parser.add_argument("--rid", required=True)
    get_parser.add_argument("--field", required=True, choices=("arch", "full", "update"))
    get_parser.set_defaults(func=get_command)

    package_parser = subparsers.add_parser("package", help="build the full and app-only release ZIPs")
    package_parser.add_argument("--rid", required=True)
    package_parser.add_argument("--publish", required=True)
    package_parser.add_argument("--dist", required=True)
    package_parser.set_defaults(func=package_command)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main(sys.argv[1:])
