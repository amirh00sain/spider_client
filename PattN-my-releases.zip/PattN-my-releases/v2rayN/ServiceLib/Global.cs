namespace ServiceLib;

public class Global
{
    public const string AppName = "PattN";
    public const string GithubUrl = "https://github.com";
    public const string GithubApiUrl = "https://api.github.com/repos";
    public const string GeoUrl = "https://github.com/Chocolate4U/Iran-v2ray-rules/releases/latest/download/{0}.dat";
    public const string SingboxRulesetUrl = @"https://raw.githubusercontent.com/chocolate4u/Iran-sing-box-rules/rule-set/{1}.srs";
    // PattN: Psiphon's signed server list as its client downloads it (the core's SERVER_LIST_URL, double slash as
    // written), shipped beside the geo files with its publication time in seconds since the epoch
    public const string PsiphonServersUrl = "https://s3.amazonaws.com//psiphon/web/mjr4-p23r-puwl/server_list_compressed";
    public const string PsiphonServersFileName = "psiphon_servers.dat";
    public const string PsiphonServersStampFileName = "psiphon_servers.stamp";

    public const string PromotionUrl = @"aHR0cHM6Ly90Lm1lL3BhdHRfY2hhbm5lbF94";
    public const string ConfigFileName = "guiNConfig.json";
    public const string CoreConfigFileName = "config.json";
    public const string CorePreConfigFileName = "configPre.json";
    public const string CoreSpeedtestConfigFileName = "configTest{0}.json";
    public const string ClashMixinConfigFileName = "Mixin.yaml";

    public const string NamespaceSample = "ServiceLib.Sample.";
    public const string V2raySampleClient = NamespaceSample + "SampleClientConfig";
    public const string SingboxSampleClient = NamespaceSample + "SingboxSampleClientConfig";
    public const string V2raySampleHttpRequestFileName = NamespaceSample + "SampleHttpRequest";
    public const string V2raySampleHttpResponseFileName = NamespaceSample + "SampleHttpResponse";
    public const string V2raySampleInbound = NamespaceSample + "SampleInbound";
    public const string V2raySampleOutbound = NamespaceSample + "SampleOutbound";
    public const string V2raySampleTunInbound = NamespaceSample + "SampleTunInbound";
    public const string V2raySampleTunRules = NamespaceSample + "SampleTunRules";
    public const string SingboxSampleOutbound = NamespaceSample + "SingboxSampleOutbound";
    public const string CustomRoutingFileName = NamespaceSample + "custom_routing_";
    public const string TunSingboxDNSFileName = NamespaceSample + "tun_singbox_dns";
    public const string TunSingboxInboundFileName = NamespaceSample + "tun_singbox_inbound";
    public const string TunSingboxRulesFileName = NamespaceSample + "tun_singbox_rules";
    public const string DNSV2rayNormalFileName = NamespaceSample + "dns_v2ray_normal";
    public const string DNSSingboxNormalFileName = NamespaceSample + "dns_singbox_normal";
    public const string ClashMixinYaml = NamespaceSample + "clash_mixin_yaml";
    public const string ClashTunYaml = NamespaceSample + "clash_tun_yaml";
    public const string LinuxAutostartConfig = NamespaceSample + "linux_autostart_config";
    public const string PacFileName = NamespaceSample + "pac";
    public const string ProxySetOSXShellFileName = NamespaceSample + "proxy_set_osx_sh";
    public const string ProxySetLinuxShellFileName = NamespaceSample + "proxy_set_linux_sh";
    public const string KillAsSudoOSXShellFileName = NamespaceSample + "kill_as_sudo_osx_sh";
    public const string KillAsSudoLinuxShellFileName = NamespaceSample + "kill_as_sudo_linux_sh";
    public const string SingboxFakeIPFilterFileName = NamespaceSample + "singbox_fakeip_filter";
    public const string ChromeRootCertFileName = NamespaceSample + "chrome_roots_pem";
    public const string MozillaRootCertFileName = NamespaceSample + "mozilla_roots_pem";

    public const string ChromeRootProvider = "chrome";
    public const string MozillaRootProvider = "mozilla";

    public const string DefaultSecurity = "auto";
    public const string DefaultNetwork = "raw";
    public const string RawHeaderHttp = "http";
    public const string None = "none";
    public const string RawNetworkAlias = "tcp";
    public const string DefaultXhttpMode = "auto";
    public const string ProxyTag = "proxy";
    public const string DirectTag = "direct";
    public const string BlockTag = "block";
    public const string DnsOutboundTag = "dns";
    public const string DnsTag = "dns-module";
    public const string DirectDnsTag = "direct-dns";
    public const string BalancerTagSuffix = "-balancer";
    // PattN: the inbound the Aether core dials out through, and the outbound its traffic leaves Xray by
    public const string AetherSecondarySocksTag = "secondary-socks";
    public const string AetherExitNodeTag = "exit-node";
    public const string StreamSecurity = "tls";
    public const string StreamSecurityReality = "reality";
    public const string Loopback = "127.0.0.1";
    public const string InboundAPIProtocol = "dokodemo-door";
    public const string HttpProtocol = "http://";
    public const string HttpsProtocol = "https://";
    public const string SocksProtocol = "socks://";
    public const string Socks5Protocol = "socks5://";
    public const string InnerUriProtocol = "v2rayn://";
    public const string AsIs = "AsIs";
    public const string IPIfNonMatch = "IPIfNonMatch";
    public const string IPOnDemand = "IPOnDemand";
    public const string GeoSitePrefix = "geosite:";
    public const string GeoIPPrefix = "geoip:";

    public const string UserEMail = "t@t.tt";
    public const string AutoRunRegPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    public const string AutoRunName = "v2rayNAutoRun";
    public const string SystemProxyExceptionsWindows = "localhost;127.*;10.*;172.16.*;172.17.*;172.18.*;172.19.*;172.20.*;172.21.*;172.22.*;172.23.*;172.24.*;172.25.*;172.26.*;172.27.*;172.28.*;172.29.*;172.30.*;172.31.*;192.168.*";
    public const string SystemProxyExceptionsLinux = "localhost,127.0.0.0/8,::1";
    public const string RoutingRuleComma = "<COMMA>";
    public const string GrpcGunMode = "gun";
    public const string GrpcMultiMode = "multi";
    public const int MaxPort = 65536;
    public const int MinFontSize = 8;
    public const int MinFontSizeCount = 13;
    public const string RebootAs = "rebootas";
    public const string AvaAssets = "avares://PattN/Assets/";
    public const string LocalAppData = "V2RAYN_LOCAL_APPLICATION_DATA_V2";
    public const string V2RayLocalAsset = "V2RAY_LOCATION_ASSET";
    public const string XrayLocalAsset = "XRAY_LOCATION_ASSET";
    public const string XrayLocalCert = "XRAY_LOCATION_CERT";
    public const int SpeedTestPageSize = 16;
    public const int SpeedTestConcurrencyCountMin = 10;
    public const string LinuxBash = "/bin/bash";
    public const string StringTrue = "true";
    public const string StringFalse = "false";
    public const int SqliteMaxBatchSize = 10000;
    public static readonly TimeSpan LocalFetch = TimeSpan.FromSeconds(5);
    public static readonly TimeSpan DirectFetch = TimeSpan.FromSeconds(10);
    public static readonly TimeSpan ProxyFetch = TimeSpan.FromSeconds(30);
    public static readonly TimeSpan DirectDownloadConnect = TimeSpan.FromSeconds(5);
    public static readonly TimeSpan ProxyDownloadConnect = TimeSpan.FromSeconds(10);

    public const string SingboxDirectDNSTagPrefix = "direct-dns-";
    public const string SingboxRemoteDNSTagPrefix = "remote-dns-";
    public const string SingboxDirectDNSTag = "direct-dns-1";
    public const string SingboxRemoteDNSTag = "remote-dns-1";
    public const string SingboxDirectDNSTagTemplate = "direct-dns-{0}";
    public const string SingboxRemoteDNSTagTemplate = "remote-dns-{0}";
    public const string SingboxLocalDNSTag = "local-local";
    public const string SingboxHostsDNSTag = "hosts-dns";
    public const string SingboxFakeDNSTag = "fake-dns";
    // PattN: sing-box's fake IP ranges are XTLS/Xray-core's default fake DNS pools (features/dns/fakedns.go)
    public const string SingboxFakeIPv4Range = "198.18.0.0/15";
    public const string SingboxFakeIPv6Range = "2001:2::/48";
    public const string SingboxSrsDownloadHttpClientTag = "srs-download-http-client";

    public const int Hysteria2DefaultHopInt = 30;
    public const string PolicyGroupExcludeKeywords = @"剩余|过期|到期|重置|[Rr]emaining|[Ee]xpir|[Rr]eset";
    public const string PolicyGroupDefaultAllFilter = $"^(?!.*(?:{PolicyGroupExcludeKeywords})).*$";

    public static readonly List<string> PolicyGroupDefaultFilterList =
    [
        // All nodes (exclude traffic/expiry info)
        PolicyGroupDefaultAllFilter,
        // Low multiplier nodes, e.g. ×0.1, 0.5x, 0.1倍
        @"^.*(?:[×xX✕*]\s*0\.[0-9]+|0\.[0-9]+\s*[×xX✕*倍]).*$",
        // Dedicated line nodes, e.g. IPLC, IEPL
        $@"^(?!.*(?:{PolicyGroupExcludeKeywords})).*(?:专线|IPLC|IEPL|中转).*$",
        // Japan nodes
        $@"^(?!.*(?:{PolicyGroupExcludeKeywords})).*(?:日本|\\b[Jj][Pp]\\b|🇯🇵|[Jj]apan).*$",
    ];

    public static readonly List<string> IEProxyProtocols =
    [
        "{ip}:{http_port}",
        "socks={ip}:{socks_port}",
        "http={ip}:{http_port};https={ip}:{http_port};ftp={ip}:{http_port};socks={ip}:{socks_port}",
        "http=http://{ip}:{http_port};https=http://{ip}:{http_port}",
        ""
    ];

    public static readonly List<string> SubConvertUrls =
    [
        @"https://sub.xeton.dev/sub?url={0}",
        @"https://api.dler.io/sub?url={0}",
        @"http://127.0.0.1:25500/sub?url={0}",
        ""
    ];

    public static readonly List<string> SubConvertConfig =
    [
        @"https://raw.githubusercontent.com/ACL4SSR/ACL4SSR/master/Clash/config/ACL4SSR_Online.ini"
    ];

    public static readonly List<string> SubConvertTargets =
    [
        "",
        "mixed",
        "v2ray",
        "clash",
        "ss"
    ];

    public static readonly List<string> SpeedTestUrls =
    [
        @"https://cachefly.cachefly.net/50mb.test",
        @"https://cachefly.cachefly.net/100mb.test",
        @"https://cachefly.cachefly.net/1mb.test",
        @"https://cachefly.cachefly.net/10mb.test",
        @"https://speed.cloudflare.com/__down?bytes=10000000",
        @"https://speed.cloudflare.com/__down?bytes=50000000",
        @"https://speed.cloudflare.com/__down?bytes=99999999",
    ];

    public static readonly List<string> SpeedPingTestUrls =
    [
        @"https://www.google.com/generate_204",
        @"https://www.youtube.com/generate_204",
        @"https://www.googlevideo.com/generate_204",
        @"https://www.gstatic.com/generate_204",
        @"https://www.apple.com/library/test/success.html",
        @"http://www.msftconnecttest.com/connecttest.txt"
    ];

    public static readonly List<string> GeoFilesSources =
    [
        "",
        @"https://github.com/runetfreedom/russia-v2ray-rules-dat/releases/latest/download/{0}.dat",
        @"https://github.com/Chocolate4U/Iran-v2ray-rules/releases/latest/download/{0}.dat",
        @"https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/{0}.dat"
    ];

    public static readonly List<string> SingboxRulesetSources =
    [
        "",
        @"https://raw.githubusercontent.com/runetfreedom/russia-v2ray-rules-dat/release/sing-box/rule-set-{0}/{1}.srs",
        @"https://raw.githubusercontent.com/chocolate4u/Iran-sing-box-rules/rule-set/{1}.srs",
        @"https://raw.githubusercontent.com/2dust/sing-box-rules/rule-set-{0}/{1}.srs"
    ];

    public static readonly List<string> RoutingRulesSources =
    [
        "",
        @"https://raw.githubusercontent.com/runetfreedom/russia-v2ray-custom-routing-list/main/v2rayN/template.json",
        @"https://raw.githubusercontent.com/Chocolate4U/Iran-v2ray-rules/main/v2rayN/template.json"
    ];

    public static readonly List<string> DNSTemplateSources =
    [
        "",
        @"https://raw.githubusercontent.com/runetfreedom/russia-v2ray-custom-routing-list/main/v2rayN/",
        @"https://raw.githubusercontent.com/Chocolate4U/Iran-v2ray-rules/main/v2rayN/"
    ];

    public static readonly Dictionary<string, string> RawHttpUserAgentTexts = new()
    {
        {"chrome","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36" },
        {"firefox","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0" },
        {"safari","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15" },
        {"edge","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.70" },
        {"none",""},
        {"golang","Go-http-client/1.1"},
        {"curl","curl/7.68.0"},
    };

    public const string Hysteria2ProtocolShare = "hy2://";

    public const string Hysteria2RealmProtocolShare = "hysteria2+realm://";

    public const string Hysteria2HttpRealmProtocolShare = "hysteria2+realm+http://";

    public const string NaiveHttpsProtocolShare = "naive+https://";

    public const string NaiveQuicProtocolShare = "naive+quic://";

    public const string SOCKS5Protocol = "socks5://";

    public const string SOCKS4Protocol = "socks4://";

    public static readonly Dictionary<EConfigType, string> ProtocolShares = new()
    {
        { EConfigType.VMess, "vmess://" },
        { EConfigType.Shadowsocks, "ss://" },
        { EConfigType.SOCKS, "socks://" },
        { EConfigType.VLESS, "vless://" },
        { EConfigType.Trojan, "trojan://" },
        { EConfigType.Hysteria2, "hysteria2://" },
        { EConfigType.TUIC, "tuic://" },
        { EConfigType.WireGuard, "wireguard://" },
        { EConfigType.Anytls, "anytls://" },
        { EConfigType.Naive, "naive://" },

        // PattN: the links of Aether profiles, the scheme PattNG's are written with, so that the two apps read each
        // other's links
        { EConfigType.Aether, "aether://" },
    };

    public static readonly Dictionary<EConfigType, string> ProtocolTypes = new()
    {
        { EConfigType.VMess, "vmess" },
        { EConfigType.Shadowsocks, "shadowsocks" },
        { EConfigType.SOCKS, "socks" },
        { EConfigType.HTTP, "http" },
        { EConfigType.VLESS, "vless" },
        { EConfigType.Trojan, "trojan" },
        { EConfigType.Hysteria2, "hysteria2" },
        { EConfigType.TUIC, "tuic" },
        { EConfigType.WireGuard, "wireguard" },
        { EConfigType.Anytls, "anytls" },
        { EConfigType.Naive, "naive" },
        { EConfigType.MASQUE, "masque" },

        // PattN: the outbound of an Aether profile is a SOCKS one to its core on the loopback address. Every type Xray
        // runs needs its name here: a proxy domain strategy of the DNS settings maps them all through this table, and a
        // missing one would leave the configuration of every profile without its DNS servers.
        { EConfigType.Aether, "socks" },
    };

    public static readonly List<string> VmessSecurities =
    [
        "aes-128-gcm",
        "chacha20-poly1305",
        "auto",
        "none",
        "zero"
    ];

    public static readonly List<string> SsSecurities =
    [
        "aes-256-gcm",
        "aes-128-gcm",
        "chacha20-poly1305",
        "chacha20-ietf-poly1305",
        "none",
        "plain"
    ];

    public static readonly List<string> SsSecuritiesInXray =
    [
        "aes-256-gcm",
        "aes-128-gcm",
        "chacha20-poly1305",
        "chacha20-ietf-poly1305",
        "xchacha20-poly1305",
        "xchacha20-ietf-poly1305",
        "none",
        "plain",
        "2022-blake3-aes-128-gcm",
        "2022-blake3-aes-256-gcm",
        "2022-blake3-chacha20-poly1305"
    ];

    public static readonly List<string> SsSecuritiesInSingbox =
    [
        "aes-256-gcm",
        "aes-192-gcm",
        "aes-128-gcm",
        "chacha20-ietf-poly1305",
        "xchacha20-ietf-poly1305",
        "none",
        "2022-blake3-aes-128-gcm",
        "2022-blake3-aes-256-gcm",
        "2022-blake3-chacha20-poly1305",
        "aes-128-ctr",
        "aes-192-ctr",
        "aes-256-ctr",
        "aes-128-cfb",
        "aes-192-cfb",
        "aes-256-cfb",
        "rc4-md5",
        "chacha20-ietf",
        "xchacha20"
    ];

    public static readonly List<string> Flows =
    [
        "",
        "xtls-rprx-vision",
        "xtls-rprx-vision-udp443"
    ];

    public static readonly List<string> Networks =
    [
        "raw",
        "xhttp",
        "kcp",
        "grpc",
        "ws",
        "httpupgrade"
    ];

    public static readonly List<string> KcpHeaderTypes =
    [
        "srtp",
        "utp",
        "wechat-video",
        "dtls",
        "wireguard",
        "dns"
    ];

    public static readonly Dictionary<string, string> KcpHeaderMaskMap = new()
    {
        { "srtp", "srtp" },
        { "utp", "utp" },
        { "wechat-video", "wechat" },
        { "dtls", "dtls" },
        { "wireguard", "wireguard" },
        { "dns", "dns" }
    };

    public static readonly List<string> CoreTypes =
    [
        "Xray",
        "sing_box"
    ];

    public static readonly HashSet<EConfigType> XraySupportConfigType =
    [
        EConfigType.VMess,
        EConfigType.VLESS,
        EConfigType.Shadowsocks,
        EConfigType.Trojan,
        EConfigType.Hysteria2,
        EConfigType.WireGuard,
        EConfigType.MASQUE,
        EConfigType.SOCKS,
        EConfigType.HTTP,

        // PattN: Xray alone runs an Aether profile, as a SOCKS outbound to its core (V2rayAetherService.cs)
        EConfigType.Aether,
    ];

    public static readonly HashSet<EConfigType> SingboxSupportConfigType =
    [
        EConfigType.VMess,
        EConfigType.VLESS,
        EConfigType.Shadowsocks,
        EConfigType.Trojan,
        EConfigType.Hysteria2,
        EConfigType.TUIC,
        EConfigType.Anytls,
        EConfigType.Naive,
        EConfigType.WireGuard,
        EConfigType.MASQUE,
        EConfigType.SOCKS,
        EConfigType.HTTP,
    ];

    public static readonly HashSet<EConfigType> SingboxOnlyConfigType = SingboxSupportConfigType.Except(XraySupportConfigType).ToHashSet();

    public static readonly List<string> DomainStrategies =
    [
        AsIs,
        IPIfNonMatch,
        IPOnDemand
    ];

    public static readonly List<string> DomainStrategies4Sbox =
    [
        "",
        "prefer_ipv4",
        "prefer_ipv6",
        "ipv4_only",
        "ipv6_only"
    ];

    public static readonly List<string> Fingerprints =
    [
        "chrome",
        "hellochrome_120",
        "firefox",
        "safari",
        "ios",
        "android",
        "edge",
        "360",
        "qq",
        "random",
        "randomized",
        "unsafe",
        ""
    ];

    // PattN: the finalMasks the finalMask fields offer (PattNG arrays.xml final_mask_preset_names/values): the name the
    // list shows, and the JSON a pick puts in the field, laid out as PattNG writes it, with "\n" line breaks whatever
    // line endings this file is checked out with.
    public static readonly List<(string Name, string Value)> FinalMaskPresets =
    [
        ("tlshello-0-len (0-104-1-0-0-114-1-1-11)",
            """
            {
              "tcp": [
                {"type": "fragment", "settings": {"packets": "tlshello", "lengths": ["0", "104", "1"], "delays": ["0"], "maxSplit": "0"}},
                {"type": "fragment", "settings": {"packets": "1-1", "lengths": ["114", "1"], "delays": ["1"], "maxSplit": "11"}}
              ]
            }
            """.ReplaceLineEndings("\n")),
        ("tlshello (6-98-1-0-0-114-1-1-11)",
            """
            {
              "tcp": [
                {"type": "fragment", "settings": {"packets": "tlshello", "lengths": ["6", "98", "1"], "delays": ["0"], "maxSplit": "0"}},
                {"type": "fragment", "settings": {"packets": "1-1", "lengths": ["114", "1"], "delays": ["1"], "maxSplit": "11"}}
              ]
            }
            """.ReplaceLineEndings("\n")),
        ("udp-noise (rnd-24-1200-1230)",
            """
            {
              "udp": [
                {
                  "type": "noise",
                  "settings": {
                    "reset": "28",
                    "noise": [
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"},
                      {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}, {"rand": "1200-1230", "delay": "10"}
                    ]
                  }
                }
              ]
            }
            """.ReplaceLineEndings("\n")),
    ];

    // PattN: the lists the cipherSuites field offers (PattNG arrays.xml cipher_suites_preset_names/values): the name the
    // list shows, and the names a pick puts in the field, joined by ':' as Xray reads them.
    public static readonly List<(string Name, string Value)> CipherSuitesPresets =
    [
        ("semi-python-cipherSuites",
            "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"),
        ("real-firefox-cipherSuites",
            "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA"),
    ];

    // PattN: the resolvers and the domains the ECH fields of the Aether editor and the WARP keys window offer (PattNG
    // arrays.xml aether_ech_dns_options / aether_ech_domain_options): each one the core takes, the default first.
    public static readonly List<string> AetherEchDnsOptions =
    [
        "udp://1.1.1.1",
        "udp://8.8.8.8",
        "https://1.1.1.1/dns-query@sni=www.microsoft.com",
        "https://doq.dns4all.eu/dns-query@address=194.0.5.3",
        "tcp://1.1.1.1",
        "tcp://8.8.8.8",
    ];

    public static readonly List<string> AetherEchDomainOptions =
    [
        "cloudflare-ech.com",
        "crypto.cloudflare.com",
        "ip.gs",
        "api.cloudflareclient.com",
        "consumer-masque.cloudflareclient.com",
        "consumer-masque-proxy.cloudflareclient.com",
    ];

    public static readonly List<string> FragmentPacketsOptions =
    [
        "tlshello",
        "1-1",
        "1-2",
        "1-3",
        "1-4",
        "1-5"
    ];

    public static readonly List<string> UserAgent =
    [
        "chrome",
        "firefox",
        "edge",
        "curl",
        "golang",
    ];

    public static readonly List<string> XhttpMode =
    [
        "auto",
        "packet-up",
        "stream-up",
        "stream-one"
    ];

    public static readonly List<string> DomainStrategy =
    [
        "AsIs",
        "UseIP",
        "UseIPv4v6",
        "UseIPv6v4",
        "UseIPv4",
        "UseIPv6",
        ""
    ];

    // PattN: values of the Xray outbound targetStrategy; the first one is Xray's default
    public static readonly List<string> TargetStrategies =
    [
        AsIs,
        "UseIP",
        "UseIPv4",
        "UseIPv6",
        "UseIPv4v6",
        "UseIPv6v4",
        "ForceIP",
        "ForceIPv4",
        "ForceIPv6",
        "ForceIPv4v6",
        "ForceIPv6v4"
    ];

    public static readonly List<string> DomainDirectDNSAddress =
    [
        "8.8.8.8",
        "1.1.1.1",
        "119.29.29.29",
        "223.5.5.5",
        "119.29.29.29,223.5.5.5,https://doh.pub/dns-query",
        "https://doh.pub/dns-query",
        "https://dns.alidns.com/dns-query",
        "https://doh.pub/dns-query,https://dns.alidns.com/dns-query",
        "localhost"
    ];

    public static readonly List<string> DomainRemoteDNSAddress =
    [
        // PattN: the default Remote DNS; an IP address needs no lookup of the DoH server's name
        "https://8.8.8.8/dns-query",
        "https://dns.google/dns-query",
        "https://cloudflare-dns.com/dns-query",
        "https://cloudflare-dns.com/dns-query,https://dns.google/dns-query,8.8.8.8",
        "https://dns.cloudflare.com/dns-query",
        "https://doh.dns.sb/dns-query",
        "https://doh.opendns.com/dns-query",
        "https://common.dot.dns.yandex.net/dns-query",
        "8.8.8.8",
        "1.1.1.1",
        "185.222.222.222",
        "208.67.222.222",
        "77.88.8.8"
    ];

    public static readonly List<string> DomainPureIPDNSAddress =
    [
        "8.8.8.8",
        "119.29.29.29",
        "223.5.5.5",
        "localhost"
    ];

    public static readonly List<LanguageOption> LanguageOptions =
    [
        new("zh-Hans", "简体中文"),
        new("zh-Hant", "繁體中文"),
        new("en", "English"),
        new("fa", "فارسی"),
        new("fr", "Français"),
        new("ru", "Русский"),
        new("hu", "Magyar"),
        new("id", "Bahasa Indonesia"),
        new("az", "Azərbaycan dili")
    ];

    public static readonly List<string> Languages =
    [
        .. LanguageOptions.Select(t => t.Value)
    ];

    public static readonly List<string> Alpns =
    [
        "h3",
        "h2",
        "http/1.1",
        "h3,h2",
        "h2,http/1.1",
        "h3,h2,http/1.1",
        ""
    ];

    public static readonly List<string> LogLevels =
    [
        "debug",
        "info",
        "warning",
        "error",
        "none"
    ];

    public static readonly Dictionary<string, string> LogLevelColors = new()
    {
        { "debug",   "#6C757D" },
        { "info",    "#2ECC71" },
        { "warning", "#FFA500" },
        { "error",   "#E74C3C" },
    };

    public static readonly List<string> InboundTags =
    [
        "tun",
        "socks",
        "socks2",
        "socks3"
    ];

    public static readonly List<string> RuleProtocols =
    [
        "http",
        "tls",
        "quic",
        "bittorrent"
    ];

    public static readonly List<string> RuleNetworks =
    [
        "",
        "tcp",
        "udp",
        "tcp,udp"
    ];

    public static readonly List<string> destOverrideProtocols =
    [
        "http",
        "tls",
        "quic",
    ];

    public static readonly List<int> TunMtus =
    [
        1280,
        1408,
        1500,
        4064,
        9000,
        65535
    ];

    public static readonly List<string> TunStacks =
    [
        "gvisor",
        "system",
        "mixed"
    ];

    public static readonly List<string> PresetMsgFilters =
    [
        "proxy",
        "direct",
        "block",
        ""
    ];

    public static readonly List<string> SingboxMuxs =
    [
        "h2mux",
        "smux",
        "yamux",
        ""
    ];

    public static readonly List<string> TuicCongestionControls =
    [
        "cubic",
        "new_reno",
        "bbr"
    ];

    public static readonly List<string> NaiveCongestionControls =
    [
        "bbr",
        "bbr2",
        "cubic",
        "reno"
    ];

    public static readonly List<string> allowSelectType =
    [
        "selector",
        "urltest",
        "loadbalance",
        "fallback"
    ];

    public static readonly List<string> notAllowTestType =
    [
        "selector",
        "urltest",
        "direct",
        "reject",
        "compatible",
        "pass",
        "loadbalance",
        "fallback"
    ];

    public static readonly List<string> proxyVehicleType =
    [
        "file",
        "http"
    ];

    public static readonly Dictionary<ECoreType, string> CoreUrls = new()
    {
        { ECoreType.v2fly, "v2fly/v2ray-core" },
        { ECoreType.v2fly_v5, "v2fly/v2ray-core" },
        { ECoreType.Xray, "patterniha/Xray-core" },
        { ECoreType.sing_box, "SagerNet/sing-box" },
        { ECoreType.mihomo, "MetaCubeX/mihomo" },
        { ECoreType.hysteria, "HyNetworks/hysteria" },
        { ECoreType.hysteria2, "HyNetworks/hysteria" },
        { ECoreType.naiveproxy, "klzgrad/naiveproxy" },
        { ECoreType.tuic, "tuic-protocol/tuic" },
        { ECoreType.juicity, "juicity/juicity" },
        { ECoreType.brook, "txthinking/brook" },
        { ECoreType.overtls, "ShadowsocksR-Live/overtls" },
        { ECoreType.shadowquic, "spongebob888/shadowquic" },
        { ECoreType.mieru, "enfein/mieru" },
        { ECoreType.v2rayN, "patterniha/PattN" },

        // PattN: the fork, not upstream CluvexStudio/Aether: only the fork's core takes --psiphon-server-entries,
        // --api-address, --api-sni and --api-host
        { ECoreType.aether, "patterniha/Aether" },
    };

    public static readonly List<string> OtherGeoUrls =
    [
        @"https://raw.githubusercontent.com/Loyalsoldier/geoip/release/geoip-only-cn-private.dat",
        @"https://raw.githubusercontent.com/Loyalsoldier/geoip/release/Country.mmdb",
        @"https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.metadb"
    ];

    public static readonly List<string> IPAPIUrls =
    [
        @"https://api.ip.sb/geoip",
        @"https://api-ipv4.ip.sb/geoip",
        @"https://api-ipv6.ip.sb/geoip",
        @"https://api.ipapi.is",
        @""
    ];

    public static readonly List<string> UdpTestTargets =
    [
        "ntp:pool.ntp.org",
        "ntp:time.google.com",
        "dns:1.1.1.1",
        "dns:8.8.8.8",
        "dns:dns.google",
        "stun:stun.voztovoice.org",
        "stun:stun.cloudflare.com",
        "stun:stun.l.google.com:19302",
        "mcbe:pms.mc-complex.com",
        "mcbe:bedrock.opblocks.com",
        "mcbe:opsucht.net",
        "mcbe:play.craftersmc.net",
        "mcbe:mps.lemoncloud.net",
        "mcbe:bedrock.talonmc.net",
    ];

    public static readonly List<string> DefaultRealmStunList =
    [
        "turn.cloudflare.com:3478",
        "stun.nextcloud.com:3478",
        "stun.sip.us:3478",
        "global.stun.twilio.com:3478",
    ];

    public static readonly List<string> OutboundTags =
    [
        ProxyTag,
        DirectTag,
        BlockTag
    ];

    public static readonly Dictionary<string, List<string>> PredefinedHosts = new()
    {
        { "dns.google", ["8.8.8.8", "8.8.4.4", "2001:4860:4860::8888", "2001:4860:4860::8844"] },
        { "dns.alidns.com", ["223.5.5.5", "223.6.6.6", "2400:3200::1", "2400:3200:baba::1"] },
        { "one.one.one.one", ["1.1.1.1", "1.0.0.1", "2606:4700:4700::1111", "2606:4700:4700::1001"] },
        { "1dot1dot1dot1.cloudflare-dns.com", ["1.1.1.1", "1.0.0.1", "2606:4700:4700::1111", "2606:4700:4700::1001"] },
        { "cloudflare-dns.com", ["104.16.249.249", "104.16.248.249", "2606:4700::6810:f8f9", "2606:4700::6810:f9f9"] },
        { "dns.cloudflare.com", ["162.159.61.8", "172.64.41.8", "2a06:98c1:52::8", "2803:f800:53::8"] },
        { "dot.pub", ["1.12.12.12", "120.53.53.53"] },
        { "doh.pub", ["1.12.12.12", "120.53.53.53"] },
        { "dns.quad9.net", ["9.9.9.9", "149.112.112.112", "2620:fe::fe", "2620:fe::9"] },
        { "dns.yandex.net", ["77.88.8.8", "77.88.8.1", "2a02:6b8::feed:0ff", "2a02:6b8:0:1::feed:0ff"] },
        { "dns.sb", ["45.11.45.11", "185.222.222.222", "2a09::", "2a11::"] },
        { "dns.umbrella.com", ["208.67.220.220", "208.67.222.222", "2620:119:35::35", "2620:119:53::53"] },
        { "dns.sse.cisco.com", ["208.67.220.220", "208.67.222.222", "2620:119:35::35", "2620:119:53::53"] },
        { "engage.cloudflareclient.com", ["162.159.192.1", "2606:4700:d0::a29f:c001"] }
    };

    public static readonly List<string> ExpectedIPs =
    [
        "geoip:cn",
        "geoip:ir",
        "geoip:ru",
        ""
    ];

    public static readonly List<string> TunIcmpRoutingPolicies =
    [
        "rule",
        "direct",
        "unreachable",
        "drop",
        "reply",
    ];

    public static readonly List<string> RootCertProviders =
    [
        "system",
        ChromeRootProvider,
        MozillaRootProvider,
    ];

    public static readonly IReadOnlyList<string> TunIPv4Address =
    [
        "172.18.0.1/30",
        "172.31.0.1/30",
        "172.20.0.1/30",
        "172.16.0.1/30",
        "192.168.100.1/30",
        "10.10.14.1/30",
        "10.1.0.1/30",
        "10.0.0.1/30",
    ];

    // Prefixes must leave room for a peer address (max /126); the sing-box system
    // stack derives a gateway from the first prefix and rejects single-address prefixes.
    public static readonly IReadOnlyList<string> TunIPv6Address =
    [
        "fc00::172:18:0:1/126",
        "fc00::172:31:0:1/126",
        "fc00::172:20:0:1/126",
        "fc00::172:16:0:1/126",
        "fc00::192:168:100:1/126",
        "fc00::10:10:14:1/126",
        "fc00::10:1:0:1/126",
        "fc00::10:0:0:1/126",
    ];
}
