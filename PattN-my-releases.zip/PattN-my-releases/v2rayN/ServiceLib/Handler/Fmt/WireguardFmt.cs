namespace ServiceLib.Handler.Fmt;

public class WireguardFmt : BaseFmt
{
    public static ProfileItem? Resolve(string str, out string msg)
    {
        msg = ResUI.ConfigurationFormatIncorrect;

        ProfileItem item = new()
        {
            ConfigType = EConfigType.WireGuard
        };

        var url = Utils.TryUri(str);
        if (url == null)
        {
            return null;
        }

        item.Address = url.IdnHost;
        item.Port = url.Port;
        item.Remarks = url.GetComponents(UriComponents.Fragment, UriFormat.Unescaped);
        item.Password = Utils.UrlDecode(url.UserInfo);

        var query = Utils.ParseQueryString(url.Query);

        var finalmaskDecoded = GetQueryDecoded(query, "fm");
        if (finalmaskDecoded.IsNotEmpty())
        {
            var node = JsonUtils.ParseJson(finalmaskDecoded);
            item.Finalmask = node != null
                ? JsonUtils.Serialize(node, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    DefaultIgnoreCondition = JsonIgnoreCondition.Never,
                    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                })
                : finalmaskDecoded;
        }
        else
        {
            item.Finalmask = string.Empty;
        }

        item.SetProtocolExtra(item.GetProtocolExtra() with
        {
            WgPublicKey = GetQueryDecoded(query, "publickey"),
            WgPresharedKey = GetQueryDecoded(query, "presharedkey"),
            WgReserved = GetQueryDecoded(query, "reserved"),
            WgInterfaceAddress = GetQueryDecoded(query, "address"),
            WgMtu = int.TryParse(GetQueryDecoded(query, "mtu"), out var mtuVal) ? mtuVal : null,
            WgDns = GetQueryDecoded(query, "dns"),
        });

        // PattN: WireGuard reads its query by hand, so dialMode is not inherited from BaseFmt.ResolveUriQuery
        item.DialMode = GetQueryDecoded(query, "dialMode");

        return item;
    }

    public static string? ToUri(ProfileItem? item)
    {
        if (item == null)
        {
            return null;
        }

        var remark = string.Empty;
        if (item.Remarks.IsNotEmpty())
        {
            remark = "#" + Utils.UrlEncode(item.Remarks);
        }

        var protoExtra = item.GetProtocolExtra();
        var dicQuery = new Dictionary<string, string>();
        // PattN: WireGuard builds its query by hand, so dialMode is not inherited from BaseFmt.ToUriQuery
        if (item.DialMode.IsNotEmpty())
        {
            dicQuery.Add("dialMode", Utils.UrlEncode(item.DialMode));
        }
        if (!protoExtra.WgPublicKey.IsNullOrEmpty())
        {
            dicQuery.Add("publickey", Utils.UrlEncode(protoExtra.WgPublicKey));
        }
        if (!protoExtra.WgPresharedKey.IsNullOrEmpty())
        {
            dicQuery.Add("presharedkey", Utils.UrlEncode(protoExtra.WgPresharedKey));
        }
        if (!protoExtra.WgReserved.IsNullOrEmpty())
        {
            dicQuery.Add("reserved", Utils.UrlEncode(protoExtra.WgReserved));
        }
        if (!protoExtra.WgInterfaceAddress.IsNullOrEmpty())
        {
            dicQuery.Add("address", Utils.UrlEncode(protoExtra.WgInterfaceAddress));
        }
        if (protoExtra.WgMtu > 0)
        {
            dicQuery.Add("mtu", protoExtra.WgMtu.ToString());
        }
        if (!protoExtra.WgDns.IsNullOrEmpty())
        {
            dicQuery.Add("dns", Utils.UrlEncode(protoExtra.WgDns));
        }
        if (item.Finalmask.IsNotEmpty())
        {
            var node = JsonUtils.ParseJson(item.Finalmask);
            var finalmask = node != null
                ? JsonUtils.Serialize(node, new JsonSerializerOptions
                {
                    WriteIndented = false,
                    DefaultIgnoreCondition = JsonIgnoreCondition.Never,
                    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                })
                : item.Finalmask;
            dicQuery.Add("fm", Utils.UrlEncode(finalmask));
        }
        return ToUri(EConfigType.WireGuard, item.Address, item.Port, item.Password, dicQuery, remark);
    }

    public static List<ProfileItem>? ResolveConfig(string strData)
    {
        var interfaceDic = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var peerDicList = new List<Dictionary<string, string>>();
        var currentDicRef = interfaceDic;
        using (var reader = new StringReader(strData))
        {
            while (reader.ReadLine() is { } line)
            {
                if (line.IsNullOrEmpty())
                {
                    continue;
                }

                var trimmedLine = line.Trim();

                if (trimmedLine.Equals("[Interface]", StringComparison.OrdinalIgnoreCase))
                {
                    currentDicRef = interfaceDic;
                    continue;
                }
                if (trimmedLine.Equals("[Peer]", StringComparison.OrdinalIgnoreCase))
                {
                    var peerDic = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    peerDicList.Add(peerDic);
                    currentDicRef = peerDic;
                    continue;
                }

                if (trimmedLine.StartsWith('[') || trimmedLine.StartsWith('#') || trimmedLine.StartsWith(';'))
                {
                    continue;
                }

                var idx = line.IndexOf('=');
                if (idx <= 0)
                {
                    continue;
                }

                var key = line[..idx].Trim();
                var value = line[(idx + 1)..].Trim();
                var commentPos = value.IndexOfAny(['#', ';']);
                if (commentPos >= 0)
                {
                    value = value[..commentPos].TrimEnd();
                }

                currentDicRef[key] = value;
            }
        }

        if (!interfaceDic.TryGetValue("PrivateKey", out var privateKey) || privateKey.IsNullOrEmpty())
        {
            return null;
        }

        var wgMtu = interfaceDic.TryGetValue("MTU", out var mtuStr) && int.TryParse(mtuStr, out var mtuVal) ? mtuVal : 0;
        var wgInterfaceAddress = interfaceDic.TryGetValue("Address", out var interfaceAddress) ? interfaceAddress : string.Empty;
        var wgDns = interfaceDic.TryGetValue("DNS", out var dns) ? dns : string.Empty;

        var index = 0;
        var resultList = new List<ProfileItem>();

        foreach (var peerDic in peerDicList)
        {
            if (!peerDic.TryGetValue("Endpoint", out var endpoint) || endpoint.IsNullOrEmpty())
            {
                continue;
            }

            if (!TryParseEndpoint(endpoint, out var peerAddress, out var peerPort))
            {
                continue;
            }

            var protoExtra = new ProtocolExtraItem
            {
                WgPublicKey = (peerDic.TryGetValue("PublicKey", out var publicKey) ? publicKey : string.Empty).NullIfEmpty(),
                WgPresharedKey = (peerDic.TryGetValue("PresharedKey", out var presharedKey) ? presharedKey : string.Empty).NullIfEmpty(),
                WgInterfaceAddress = wgInterfaceAddress,
                WgReserved = (peerDic.TryGetValue("Reserved", out var reserved) ? reserved : string.Empty).NullIfEmpty(),
                WgMtu = wgMtu > 0 ? wgMtu : null,
                WgDns = wgDns,
            };

            var item = new ProfileItem
            {
                Remarks = $"{nameof(EConfigType.WireGuard)} Peer {index + 1}",
                ConfigType = EConfigType.WireGuard,
                Address = peerAddress,
                Port = peerPort,
                Password = privateKey,
            };
            item.SetProtocolExtra(protoExtra);
            resultList.Add(item);

            index += 1;
        }

        return resultList;
    }

    private static bool TryParseEndpoint(string endpoint, out string address, out int port)
    {
        address = string.Empty;
        port = 2408;

        var trimmedEndpoint = endpoint.Trim();
        if (trimmedEndpoint.IsNullOrEmpty())
        {
            return false;
        }

        if (trimmedEndpoint[0] == '[')
        {
            var closeIndex = trimmedEndpoint.IndexOf(']');
            if (closeIndex <= 1)
            {
                return false;
            }

            address = trimmedEndpoint[1..closeIndex].Trim();
            var portIndex = closeIndex + 1;
            if (portIndex < trimmedEndpoint.Length && trimmedEndpoint[portIndex] == ':' &&
                int.TryParse(trimmedEndpoint[(portIndex + 1)..].Trim(), out var bracketedPort) && bracketedPort is > 0 and <= 65535)
            {
                port = bracketedPort;
            }

            return address.IsNotEmpty();
        }

        var lastColonIndex = trimmedEndpoint.LastIndexOf(':');
        if (lastColonIndex <= 0)
        {
            address = trimmedEndpoint;
            return true;
        }

        address = trimmedEndpoint[..lastColonIndex].Trim();
        var portText = trimmedEndpoint[(lastColonIndex + 1)..].Trim();
        if (address.IsNullOrEmpty())
        {
            return false;
        }

        if (int.TryParse(portText, out var parsedPortValue) && parsedPortValue is > 0 and <= 65535)
        {
            port = parsedPortValue;
            return true;
        }

        address = trimmedEndpoint;
        return true;
    }
}
