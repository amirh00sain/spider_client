namespace ServiceLib.Services.CoreConfig;

public partial class CoreConfigV2rayService
{
    private void GenOutbounds()
    {
        var proxyOutboundList = BuildAllProxyOutbounds();
        _coreConfig.outbounds.InsertRange(0, proxyOutboundList);
        if (proxyOutboundList.Count(n => n.tag.StartsWith(Global.ProxyTag)) > 1)
        {
            var multipleLoad = _node.GetProtocolExtra().MultipleLoad ?? EMultipleLoad.LeastPing;
            GenObservatory(multipleLoad);
            GenBalancer(multipleLoad);
        }
        if (context.IsTunEnabled)
        {
            _coreConfig.outbounds.Add(BuildDnsOutbound());
        }
    }

    private List<Outbounds4Ray> BuildAllProxyOutbounds(string baseTagName = Global.ProxyTag)
    {
        var proxyOutboundList = new List<Outbounds4Ray>();
        if (_node.ConfigType.IsGroupType())
        {
            proxyOutboundList.AddRange(BuildGroupProxyOutbounds(baseTagName));
        }
        else
        {
            proxyOutboundList.Add(BuildProxyOutbound(baseTagName));
        }
        return proxyOutboundList;
    }

    private List<Outbounds4Ray> BuildGroupProxyOutbounds(string baseTagName = Global.ProxyTag)
    {
        var proxyOutboundList = new List<Outbounds4Ray>();
        switch (_node.ConfigType)
        {
            case EConfigType.PolicyGroup:
                proxyOutboundList.AddRange(BuildOutboundsList(baseTagName));
                break;

            case EConfigType.ProxyChain:
                proxyOutboundList.AddRange(BuildChainOutboundsList(baseTagName));
                break;
        }
        return proxyOutboundList;
    }

    private Outbounds4Ray BuildProxyOutbound(string baseTagName = Global.ProxyTag)
    {
        var txtOutbound = EmbedUtils.GetEmbedText(Global.V2raySampleOutbound);
        var outbound = JsonUtils.Deserialize<Outbounds4Ray>(txtOutbound);
        if (_node.ConfigType == EConfigType.Outbound)
        {
            outbound.tag = baseTagName;
            context.CustomOutboundMap[outbound] = _node.IndexId;
            return outbound;
        }
        FillOutbound(outbound);
        // PattN: per-profile targetStrategy, set on the outbound itself (not in sockopt)
        outbound.targetStrategy = _node.GetTargetStrategy();
        outbound.tag = baseTagName;
        // PattN: an Aether outbound's targetStrategy defaults by where its traffic leaves, and GenAether reads it
        if (_node.ConfigType == EConfigType.Aether)
        {
            RecordAetherOutbound(outbound);
        }
        return outbound;
    }

    private void FillOutbound(Outbounds4Ray outbound)
    {
        try
        {
            var protocolExtra = _node.GetProtocolExtra();
            var muxEnabled = _node.MuxEnabled ?? false;
            var outboundSettings = outbound.settings;
            switch (_node.ConfigType)
            {
                case EConfigType.VMess:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        outboundSettings.id = _node.Password;
                        outboundSettings.alterId = int.TryParse(protocolExtra?.AlterId, out var result) ? result : 0;
                        outboundSettings.email = Global.UserEMail;
                        if (Global.VmessSecurities.Contains(protocolExtra.VmessSecurity))
                        {
                            outboundSettings.security = protocolExtra.VmessSecurity;
                        }
                        else
                        {
                            outboundSettings.security = Global.DefaultSecurity;
                        }

                        FillOutboundMux(outbound, muxEnabled, muxEnabled);
                        break;
                    }
                case EConfigType.Shadowsocks:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        outboundSettings.password = _node.Password;
                        outboundSettings.method = AppManager.Instance.GetShadowsocksSecurities(_node).Contains(protocolExtra.SsMethod)
                            ? protocolExtra.SsMethod : "none";
                        outboundSettings.uot = protocolExtra.Uot == true ? true : null;

                        outboundSettings.ota = false;

                        FillOutboundMux(outbound);
                        break;
                    }
                case EConfigType.SOCKS:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        if (_node.Username.IsNotEmpty()
                            && _node.Password.IsNotEmpty())
                        {
                            outboundSettings.user = _node.Username;
                            outboundSettings.pass = _node.Password;
                            outboundSettings.email = Global.UserEMail;
                        }

                        FillOutboundMux(outbound);
                        break;
                    }
                case EConfigType.HTTP:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;

                        if (protocolExtra.HttpHeaders.IsNotEmpty())
                        {
                            outboundSettings.headers = JsonUtils.ParseJson(protocolExtra.HttpHeaders);
                        }

                        if (_node.Username.IsNotEmpty()
                            && _node.Password.IsNotEmpty())
                        {
                            outboundSettings.user = _node.Username;
                            outboundSettings.pass = _node.Password;
                            outboundSettings.email = Global.UserEMail;
                        }

                        FillOutboundMux(outbound);
                        break;
                    }
                case EConfigType.VLESS:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        outboundSettings.id = _node.Password;
                        outboundSettings.email = Global.UserEMail;
                        outboundSettings.encryption = protocolExtra.VlessEncryption;

                        if (protocolExtra.Flow.IsNullOrEmpty())
                        {
                            FillOutboundMux(outbound, muxEnabled, muxEnabled);
                        }
                        else
                        {
                            outboundSettings.flow = protocolExtra.Flow;
                            FillOutboundMux(outbound, false, muxEnabled);
                        }
                        break;
                    }
                case EConfigType.Trojan:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        outboundSettings.password = _node.Password;

                        outboundSettings.ota = false;

                        FillOutboundMux(outbound);
                        break;
                    }
                case EConfigType.Hysteria2:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        outboundSettings.version = 2;
                        break;
                    }
                case EConfigType.MASQUE:
                    {
                        outboundSettings.address = _node.Address;
                        outboundSettings.port = _node.Port;
                        break;
                    }
                case EConfigType.WireGuard:
                    {
                        var address = _node.Address;
                        if (Utils.IsIpv6(address))
                        {
                            address = $"[{address}]";
                        }
                        var peer = new WireguardPeer4Ray
                        {
                            publicKey = protocolExtra.WgPublicKey ?? "",
                            endpoint = address + ":" + _node.Port.ToString(),
                            preSharedKey = protocolExtra.WgPresharedKey,
                        };
                        var setting = new Outboundsettings4Ray
                        {
                            address = Utils.String2List(protocolExtra.WgInterfaceAddress)?.Select(s => s.Trim()).ToList() ?? ["172.16.0.2/32"],
                            secretKey = _node.Password,
                            reserved = Utils.String2List(protocolExtra.WgReserved)?.Select(s => s.Trim()).Select(int.Parse).ToList(),
                            mtu = protocolExtra.WgMtu > 0 ? protocolExtra.WgMtu : Global.TunMtus.First(),
                            remoteDNS = Utils.String2List(protocolExtra.WgDns)?.Select(s => s.Trim()).ToList(),
                            peers = [peer],
                        };
                        outbound.settings = setting;
                        break;
                    }
                // PattN: a SOCKS outbound to the Aether core on the loopback address, with no stream settings of its own
                case EConfigType.Aether:
                    {
                        FillAetherOutbound(outbound);
                        return;
                    }
            }

            outbound.protocol = Global.ProtocolTypes[_node.ConfigType];
            if (_node.ConfigType == EConfigType.Hysteria2)
            {
                outbound.protocol = "hysteria";
            }
            FillBoundStreamSettings(outbound);
        }
        catch (Exception ex)
        {
            Logging.SaveLog(_tag, ex);
        }
    }

    private void FillOutboundMux(Outbounds4Ray outbound, bool enabledTCP = false, bool enabledUDP = false)
    {
        try
        {
            outbound.mux.enabled = false;
            outbound.mux.concurrency = -1;

            if (enabledTCP)
            {
                outbound.mux.enabled = true;
                outbound.mux.concurrency = _config.Mux4RayItem.Concurrency;
            }
            else if (enabledUDP)
            {
                outbound.mux.enabled = true;
                outbound.mux.xudpConcurrency = _config.Mux4RayItem.XudpConcurrency;
                outbound.mux.xudpProxyUDP443 = _config.Mux4RayItem.XudpProxyUDP443;
            }
        }
        catch (Exception ex)
        {
            Logging.SaveLog(_tag, ex);
        }
    }

    private void FillBoundStreamSettings(Outbounds4Ray outbound)
    {
        try
        {
            outbound.streamSettings ??= new();
            var streamSettings = outbound.streamSettings;
            var network = _node.GetNetwork();
            if (_node.ConfigType == EConfigType.Hysteria2)
            {
                network = "hysteria";
            }
            else if (_node.ConfigType == EConfigType.MASQUE)
            {
                network = "masque";
            }
            streamSettings.network = network;
            if (_node.DialMode.IsNotEmpty())
            {
                // Only dialMode is set here so sockopt options added later (dialerProxy, domainStrategy, ...) are kept.
                streamSettings.sockopt ??= new();
                streamSettings.sockopt.dialMode = _node.DialMode;
            }
            var transport = _node.GetTransportExtra();
            var protocolExtra = _node.GetProtocolExtra();
            var host = string.Empty;
            var path = string.Empty;
            var kcpSeed = string.Empty;
            var kcpMtu = 0;
            var headerType = string.Empty;
            var xhttpExtra = string.Empty;
            switch (network)
            {
                case nameof(ETransport.raw):
                    host = transport.Host?.TrimEx() ?? string.Empty;
                    path = transport.Path?.TrimEx() ?? string.Empty;
                    headerType = transport.RawHeaderType?.TrimEx() ?? string.Empty;
                    break;

                case nameof(ETransport.kcp):
                    kcpSeed = transport.KcpSeed?.TrimEx() ?? string.Empty;
                    headerType = transport.KcpHeaderType?.TrimEx() ?? string.Empty;
                    kcpMtu = transport.KcpMtu > 0 ? transport.KcpMtu!.Value : _config.KcpItem.Mtu;
                    break;

                case nameof(ETransport.ws):
                    host = transport.Host?.TrimEx() ?? string.Empty;
                    path = transport.Path?.TrimEx() ?? string.Empty;
                    break;

                case nameof(ETransport.httpupgrade):
                    host = transport.Host?.TrimEx() ?? string.Empty;
                    path = transport.Path?.TrimEx() ?? string.Empty;
                    break;

                case nameof(ETransport.xhttp):
                    host = transport.Host?.TrimEx() ?? string.Empty;
                    path = transport.Path?.TrimEx() ?? string.Empty;
                    headerType = transport.XhttpMode?.TrimEx() ?? string.Empty;
                    xhttpExtra = transport.XhttpExtra?.TrimEx() ?? string.Empty;
                    break;

                case nameof(ETransport.grpc):
                    host = transport.GrpcAuthority?.TrimEx() ?? string.Empty;
                    path = transport.GrpcServiceName?.TrimEx() ?? string.Empty;
                    headerType = transport.GrpcMode?.TrimEx() ?? string.Empty;
                    break;
            }

            var sni = _node.Sni.TrimEx();
            var useragent = _config.CoreBasicItem.DefUserAgent ?? string.Empty;

            //if tls
            if (_node.StreamSecurity == Global.StreamSecurity)
            {
                streamSettings.security = _node.StreamSecurity;

                TlsSettings4Ray tlsSettings = new()
                {
                    alpn = _node.GetAlpn(),
                    cipherSuites = _node.CipherSuites.IsNullOrEmpty() ? null : _node.CipherSuites,
                    fingerprint = _node.Fingerprint.IsNullOrEmpty() ? _config.CoreBasicItem.DefFingerprint : _node.Fingerprint,
                    echConfigList = _node.EchConfigList.NullIfEmpty(),
                    verifyPeerCertByName = _node.VerifyPeerCertByName.NullIfEmpty(),
                };
                if (sni.IsNotEmpty())
                {
                    tlsSettings.serverName = sni;
                }
                else if (host.IsNotEmpty())
                {
                    tlsSettings.serverName = Utils.String2List(host)?.First();
                }
                if (!tlsSettings.echConfigList.IsNullOrEmpty())
                {
                    // For legacy xray compatibility, remove this in the future
                    tlsSettings.echForceQuery = "full";
                }
                // PattN: the ECH config query goes through the profile's ECH outbound, which is
                // appended to the config after every other outbound (AppendEchOutbounds)
                if (NodeValidator.ValidateEchOutbound(_node, out var echOutbound) == null && echOutbound != null)
                {
                    tlsSettings.echSockopt = new Sockopt4Ray { dialerProxy = AddEchOutbound(echOutbound) };
                }
                var certs = CertPemManager.ParsePemChain(_node.Cert);
                if (certs.Count > 0)
                {
                    var certsettings = new List<CertificateSettings4Ray>();
                    foreach (var cert in certs)
                    {
                        var certPerLine = cert.Split("\n").ToList();
                        certsettings.Add(new CertificateSettings4Ray
                        {
                            certificate = certPerLine,
                            usage = "verify",
                        });
                    }
                    tlsSettings.certificates = certsettings;
                    tlsSettings.disableSystemRoot = true;
                }
                else if (!_node.CertSha.IsNullOrEmpty())
                {
                    tlsSettings.pinnedPeerCertSha256 = _node.CertSha;
                }
                streamSettings.tlsSettings = tlsSettings;
            }

            //if Reality
            if (_node.StreamSecurity == Global.StreamSecurityReality)
            {
                streamSettings.security = _node.StreamSecurity;

                TlsSettings4Ray realitySettings = new()
                {
                    fingerprint = _node.Fingerprint.IsNullOrEmpty() ? _config.CoreBasicItem.DefFingerprint : _node.Fingerprint,
                    serverName = sni,
                    publicKey = _node.PublicKey,
                    shortId = _node.ShortId,
                    spiderX = _node.SpiderX,
                    mldsa65Verify = _node.Mldsa65Verify,
                    show = false,
                };

                streamSettings.realitySettings = realitySettings;
            }

            //streamSettings
            switch (network)
            {
                case nameof(ETransport.kcp):
                    KcpSettings4Ray kcpSettings = new()
                    {
                        mtu = kcpMtu,
                        tti = _config.KcpItem.Tti,
                        uplinkCapacity = _config.KcpItem.UplinkCapacity,
                        downlinkCapacity = _config.KcpItem.DownlinkCapacity,
                        cwndMultiplier = _config.KcpItem.CwndMultiplier,
                        maxSendingWindow = _config.KcpItem.MaxSendingWindow,
                    };

                    var kcpFinalmask = new Finalmask4Ray();
                    if (Global.KcpHeaderMaskMap.TryGetValue(headerType, out var header))
                    {
                        kcpFinalmask.udp =
                        [
                            new Mask4Ray
                            {
                                type = "mkcp-legacy",
                                settings = new MaskSettings4Ray { header = header },
                            }
                        ];
                    }
                    kcpFinalmask.udp ??= [];
                    if (kcpSeed.IsNullOrEmpty())
                    {
                        kcpFinalmask.udp.Add(new Mask4Ray
                        {
                            type = "mkcp-legacy",
                        });
                    }
                    else
                    {
                        kcpFinalmask.udp.Add(new Mask4Ray
                        {
                            type = "mkcp-legacy",
                            settings = new MaskSettings4Ray { value = kcpSeed },
                        });
                    }
                    kcpFinalmask.udp?.Reverse();
                    streamSettings.kcpSettings = kcpSettings;
                    streamSettings.finalmask = kcpFinalmask;
                    break;
                //ws
                case nameof(ETransport.ws):
                    WsSettings4Ray wsSettings = new();

                    if (host.IsNotEmpty())
                    {
                        wsSettings.host = host;
                    }
                    if (path.IsNotEmpty())
                    {
                        wsSettings.path = path;
                    }
                    if (useragent.IsNotEmpty())
                    {
                        wsSettings.headers ??= new Headers4Ray();
                        wsSettings.headers.UserAgent = useragent;
                    }
                    streamSettings.wsSettings = wsSettings;

                    break;
                //httpupgrade
                case nameof(ETransport.httpupgrade):
                    HttpupgradeSettings4Ray httpupgradeSettings = new();

                    if (host.IsNotEmpty())
                    {
                        httpupgradeSettings.host = host;
                    }
                    if (path.IsNotEmpty())
                    {
                        httpupgradeSettings.path = path;
                    }
                    if (useragent.IsNotEmpty())
                    {
                        httpupgradeSettings.headers ??= new Headers4Ray();
                        httpupgradeSettings.headers.UserAgent = useragent;
                    }
                    streamSettings.httpupgradeSettings = httpupgradeSettings;

                    break;
                //xhttp
                case nameof(ETransport.xhttp):
                    streamSettings.network = nameof(ETransport.xhttp);
                    XhttpSettings4Ray xhttpSettings = new();

                    if (path.IsNotEmpty())
                    {
                        xhttpSettings.path = path;
                    }
                    if (host.IsNotEmpty())
                    {
                        xhttpSettings.host = host;
                    }
                    if (headerType.IsNotEmpty() && Global.XhttpMode.Contains(headerType))
                    {
                        xhttpSettings.mode = headerType;
                    }
                    if (xhttpExtra.IsNotEmpty())
                    {
                        xhttpSettings.extra = JsonUtils.ParseJson(xhttpExtra);
                    }

                    streamSettings.xhttpSettings = xhttpSettings;
                    FillOutboundMux(outbound);

                    break;

                case nameof(ETransport.grpc):
                    GrpcSettings4Ray grpcSettings = new()
                    {
                        authority = host.NullIfEmpty(),
                        serviceName = path,
                        multiMode = headerType == Global.GrpcMultiMode,
                        idle_timeout = _config.GrpcItem.IdleTimeout,
                        health_check_timeout = _config.GrpcItem.HealthCheckTimeout,
                        permit_without_stream = _config.GrpcItem.PermitWithoutStream,
                        initial_windows_size = _config.GrpcItem.InitialWindowsSize,
                        user_agent = useragent.NullIfEmpty(),
                    };
                    streamSettings.grpcSettings = grpcSettings;
                    break;

                case "hysteria":
                    var ports = protocolExtra?.Ports;
                    int? upMbps = protocolExtra?.UpMbps is { } su and >= 0
                        ? su
                        : _config.HysteriaItem.UpMbps;
                    int? downMbps = protocolExtra?.DownMbps is { } sd and >= 0
                        ? sd
                        : _config.HysteriaItem.DownMbps;
                    var hopInterval = !protocolExtra.HopInterval.IsNullOrEmpty()
                        ? protocolExtra.HopInterval
                        : (_config.HysteriaItem.HopInterval >= 5
                            ? _config.HysteriaItem.HopInterval
                            : Global.Hysteria2DefaultHopInt).ToString();
                    var hy2Finalmask = new Finalmask4Ray();
                    var quicParams = new QuicParams4Ray();
                    if (!ports.IsNullOrEmpty() &&
                        (ports.Contains(':') || ports.Contains('-') || ports.Contains(',')))
                    {
                        var udpHop = new UdpHop4Ray
                        {
                            ports = ports.Replace(':', '-'),
                            interval = hopInterval,
                        };
                        quicParams.udpHop = udpHop;
                    }
                    if (upMbps > 0 || downMbps > 0)
                    {
                        quicParams.congestion = "brutal";
                        quicParams.brutalUp = upMbps > 0 ? $"{upMbps}mbps" : null;
                        quicParams.brutalDown = downMbps > 0 ? $"{downMbps}mbps" : null;
                    }
                    else
                    {
                        quicParams.congestion = "bbr";
                    }
                    hy2Finalmask.quicParams = quicParams;
                    hy2Finalmask.udp ??= [];
                    if (HyRealm.TryParse(protocolExtra.Hy2RealmUrl, out var realm)
                        && realm is not null)
                    {
                        hy2Finalmask.udp.Add(new Mask4Ray
                        {
                            type = "realm",
                            settings = new MaskSettings4Ray { url = realm.ToUriForFinalmask(), stunServers = realm.StunList },
                        });
                    }
                    if (!protocolExtra.SalamanderPass.IsNullOrEmpty())
                    {
                        var isGecko = !protocolExtra.GeckoMinPacketSize.IsNullOrEmpty() || !protocolExtra.GeckoMaxPacketSize.IsNullOrEmpty();
                        var salamanderSettings = new MaskSettings4Ray
                        {
                            password = protocolExtra.SalamanderPass.TrimEx(),
                        };
                        if (isGecko)
                        {
                            salamanderSettings.packetSize = $"{protocolExtra.GeckoMinPacketSize}-{protocolExtra.GeckoMaxPacketSize}";
                        }
                        hy2Finalmask.udp.Add(new Mask4Ray
                        {
                            type = "salamander",
                            settings = salamanderSettings,
                        });
                    }
                    streamSettings.hysteriaSettings = new()
                    {
                        version = 2,
                        auth = _node.Password,
                    };
                    hy2Finalmask.udp?.Reverse();
                    streamSettings.finalmask = hy2Finalmask;
                    break;

                case "masque":
                    var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    var authValue = $"Basic {Utils.Base64Encode($"{_node.Username}:{_node.Password}")}";
                    headers.Add("Authorization", authValue);
                    if (!string.IsNullOrEmpty(protocolExtra?.MasqueHeaders))
                    {
                        var userHeaders = Utils.ParseHeaders(protocolExtra.MasqueHeaders)
                            .GroupBy(x => x.Item1, StringComparer.OrdinalIgnoreCase)
                            .ToDictionary(
                                g => g.Key,
                                g => string.Join(", ", g.Select(x => x.Item2)),
                                StringComparer.OrdinalIgnoreCase
                            );
                        if (userHeaders.TryGetValue("Authorization", out var userAuthValue))
                        {
                            headers["Authorization"] = userAuthValue;
                        }
                        headers = userHeaders;
                    }
                    streamSettings.masqueSettings = new()
                    {
                        path = protocolExtra?.MasquePath.NullIfEmpty(),
                        headers = headers.Count > 0 ? headers : null,
                    };
                    break;

                default:
                    // raw
                    if (headerType == Global.RawHeaderHttp)
                    {
                        RawSettings4Ray rawSettings = new()
                        {
                            header = new Header4Ray
                            {
                                type = headerType
                            }
                        };

                        //request Host
                        var request = EmbedUtils.GetEmbedText(Global.V2raySampleHttpRequestFileName);
                        var useragentValue = Global.RawHttpUserAgentTexts.GetValueOrDefault(useragent, useragent);
                        var arrHost = host.Split(',');
                        var host2 = string.Join(",".AppendQuotes(), arrHost);
                        request = request.Replace("$requestHost$", $"{host2.AppendQuotes()}");
                        request = request.Replace("$requestUserAgent$", $"{useragentValue.AppendQuotes()}");
                        //Path
                        var pathHttp = @"/";
                        if (path.IsNotEmpty())
                        {
                            var arrPath = path.Split(',');
                            pathHttp = string.Join(",".AppendQuotes(), arrPath);
                        }
                        request = request.Replace("$requestPath$", $"{pathHttp.AppendQuotes()}");
                        rawSettings.header.request = JsonUtils.Deserialize<object>(request);

                        streamSettings.rawSettings = rawSettings;
                    }
                    break;
            }

            if (!_node.Finalmask.IsNullOrEmpty())
            {
                streamSettings.finalmask = JsonUtils.ParseJson(_node.Finalmask);
            }
        }
        catch (Exception ex)
        {
            Logging.SaveLog(_tag, ex);
        }
    }

    private List<Outbounds4Ray> BuildOutboundsList(string baseTagName = Global.ProxyTag)
    {
        var nodes = new List<ProfileItem>();
        foreach (var nodeId in Utils.String2List(_node.GetProtocolExtra().ChildItems) ?? [])
        {
            if (context.AllProxiesMap.TryGetValue(nodeId, out var node))
            {
                nodes.Add(node);
            }
        }
        var resultOutbounds = new List<Outbounds4Ray>();
        for (var i = 0; i < nodes.Count; i++)
        {
            var node = nodes[i];
            var currentTag = $"{baseTagName}-{i + 1}-{node.Remarks}";

            if (nodes.Count == 1)
            {
                currentTag = baseTagName;
            }

            if (node.ConfigType.IsGroupType())
            {
                var childProfiles = new CoreConfigV2rayService(context with { Node = node, }).BuildGroupProxyOutbounds(currentTag);
                resultOutbounds.AddRange(childProfiles);
                continue;
            }
            var outbound = new CoreConfigV2rayService(context with { Node = node, }).BuildProxyOutbound();
            outbound.tag = currentTag;
            resultOutbounds.Add(outbound);
        }
        return resultOutbounds;
    }

    private List<Outbounds4Ray> BuildChainOutboundsList(string baseTagName = Global.ProxyTag)
    {
        var nodes = new List<ProfileItem>();
        foreach (var nodeId in Utils.String2List(_node.GetProtocolExtra().ChildItems) ?? [])
        {
            if (context.AllProxiesMap.TryGetValue(nodeId, out var node))
            {
                nodes.Add(node);
            }
        }
        // Based on actual network flow instead of data packets
        var nodesReverse = nodes.AsEnumerable().Reverse().ToList();
        // PattN: an Aether hop dials through no hop, and the hop on its entry side is the exit-node (V2rayAetherService.cs)
        var aetherChain = new AetherChainLayout(context, _node, nodesReverse, baseTagName);
        var resultOutbounds = new List<Outbounds4Ray>();
        for (var i = 0; i < nodesReverse.Count; i++)
        {
            var node = nodesReverse[i];
            var currentTag = i == 0 ? baseTagName : $"chain-{baseTagName}-{i}-{node.Remarks}";
            var dialerProxyTag = i != nodesReverse.Count - 1 ? $"chain-{baseTagName}-{i + 1}-{nodesReverse[i + 1].Remarks}" : null;
            // PattN: the hop the Aether hop dials out through is tagged exit-node, and the Aether hop dials through none
            (currentTag, dialerProxyTag) = aetherChain.Tags(i, currentTag, dialerProxyTag);
            if (node.ConfigType.IsGroupType())
            {
                var childProfiles = new CoreConfigV2rayService(context with { Node = node, }).BuildGroupProxyOutbounds(currentTag);
                // PattN: an Aether profile inside a group or a chain that is a hop
                RefuseAetherInGroupHop(node, childProfiles);
                if (!dialerProxyTag.IsNullOrEmpty())
                {
                    var chainEndNodes =
                        childProfiles.Where(n => n?.streamSettings?.sockopt?.dialerProxy?.IsNullOrEmpty() ?? true);
                    foreach (var chainEndNode in chainEndNodes)
                    {
                        FillDialerProxy(chainEndNode, dialerProxyTag);
                    }
                }
                if (i != 0)
                {
                    var chainStartNodes = childProfiles.Where(n => n.tag.StartsWith(currentTag)).ToList();
                    if (chainStartNodes.Count == 1)
                    {
                        var firstChainTag = chainStartNodes.First().tag;
                        foreach (var existedChainEndNode in resultOutbounds.Where(n => n.streamSettings?.sockopt?.dialerProxy == currentTag))
                        {
                            FillDialerProxy(existedChainEndNode, firstChainTag);
                        }
                    }
                    else if (chainStartNodes.Count > 1)
                    {
                        var existedChainNodes = CloneOutbounds(resultOutbounds);
                        resultOutbounds.Clear();
                        var j = 0;
                        foreach (var chainStartNode in chainStartNodes)
                        {
                            var existedChainNodesClone = CloneOutbounds(existedChainNodes);
                            foreach (var existedChainNode in existedChainNodesClone)
                            {
                                var cloneTag = $"{existedChainNode.tag}-clone-{j + 1}";
                                existedChainNode.tag = cloneTag;
                            }
                            for (var k = 0; k < existedChainNodesClone.Count; k++)
                            {
                                var existedChainNode = existedChainNodesClone[k];
                                var previousDialerProxyTag = existedChainNode.streamSettings?.sockopt?.dialerProxy;
                                var nextTag = k + 1 < existedChainNodesClone.Count
                                    ? existedChainNodesClone[k + 1].tag
                                    : chainStartNode.tag;
                                FillDialerProxy(existedChainNode,
                                    previousDialerProxyTag == currentTag ? chainStartNode.tag : nextTag);
                                resultOutbounds.Add(existedChainNode);
                            }
                            j++;
                        }
                    }
                }
                resultOutbounds.AddRange(childProfiles);
                continue;
            }
            var outbound = new CoreConfigV2rayService(context with { Node = node, }).BuildProxyOutbound();

            outbound.tag = currentTag;

            if (!dialerProxyTag.IsNullOrEmpty())
            {
                FillDialerProxy(outbound, dialerProxyTag);
            }
            // PattN: the Aether hop learns its chain and its way out
            aetherChain.Settle(i, outbound);

            resultOutbounds.Add(outbound);
        }
        return resultOutbounds;
    }

    private static void FillDialerProxy(Outbounds4Ray outbound, string dialerProxyTag)
    {
        outbound.streamSettings ??= new();
        outbound.streamSettings.sockopt ??= new();
        outbound.streamSettings.sockopt.dialerProxy = dialerProxyTag;

        // xhttp download dialer proxy
        if (outbound?.streamSettings?.xhttpSettings?.extra is not null)
        {
            var xhttpExtra = JsonUtils.ParseJson(JsonUtils.Serialize(outbound.streamSettings.xhttpSettings!.extra));
            if (xhttpExtra is JsonObject xhttpExtraObject
                && xhttpExtraObject["downloadSettings"] is JsonObject downloadSettings)
            {
                var sockopt = downloadSettings["sockopt"] as JsonObject ?? new JsonObject();
                sockopt["dialerProxy"] = dialerProxyTag;
                downloadSettings["sockopt"] = sockopt;
                outbound.streamSettings.xhttpSettings.extra = xhttpExtraObject;
            }
        }
    }

    private static Outbounds4Ray BuildDnsOutbound()
    {
        var outbound = new Outbounds4Ray
        {
            tag = Global.DnsOutboundTag,
            protocol = "dns",
            settings = new Outboundsettings4Ray { userLevel = 12 },
        };
        return outbound;
    }

    private void ApplyOutboundFragment()
    {
        var actOutboundWithTlsList =
            _coreConfig.outbounds.Where(n => n.streamSettings?.security.IsNullOrEmpty() == false
                                             && (n.streamSettings?.sockopt?.dialerProxy?.IsNullOrEmpty() ?? true))
                .ToList();

        var fragmentMask = BuildFragmentsMasks();

        foreach (var outbound in actOutboundWithTlsList)
        {
            var finalMaskJsonObj = JsonUtils.ParseJson(JsonUtils.Serialize(outbound.streamSettings?.finalmask)) as JsonObject ?? new JsonObject();
            // tcp fragment
            var tcpFinalmaskList = finalMaskJsonObj["tcp"] as JsonArray ?? [];
            if (tcpFinalmaskList.Count == 0)
            {
                tcpFinalmaskList.Add(JsonUtils.SerializeToNode(fragmentMask));
                finalMaskJsonObj["tcp"] = tcpFinalmaskList;
            }
            // write back
            outbound.streamSettings.finalmask = finalMaskJsonObj;
        }
    }

    private void ApplyFinalFragment()
    {
        var fragmentMask = BuildFragmentsMasks();
        var actOutboundList = _coreConfig.outbounds.Where(n => n.tag.StartsWith(Global.ProxyTag)).ToList();

        var fragmentFreedom = new Outbounds4Ray()
        {
            tag = $"{Global.ProxyTag}-fragment-freedom",
            protocol = "freedom",
            streamSettings = new StreamSettings4Ray
            {
                finalmask = new Finalmask4Ray
                {
                    tcp = [fragmentMask],
                },
            },
        };

        foreach (var outbound in actOutboundList)
        {
            var index = _coreConfig.outbounds.IndexOf(outbound);
            var originalTag = outbound.tag;
            var afterTag = $"fragment-{originalTag}";
            var cloneFragmentFreedom = JsonUtils.DeepCopy(fragmentFreedom);
            cloneFragmentFreedom.tag = originalTag;
            cloneFragmentFreedom.streamSettings.sockopt ??= new();
            cloneFragmentFreedom.streamSettings.sockopt.dialerProxy = afterTag;

            outbound.tag = afterTag;
            _coreConfig.outbounds.Insert(index, cloneFragmentFreedom);
        }
    }

    private Mask4Ray BuildFragmentsMasks()
    {
        var configPackets = _config.Fragment4RayItem?.Packets.NullIfEmpty() ?? "tlshello";
        var configLengths = _config.Fragment4RayItem?.Lengths ?? [];
        var configDelays = _config.Fragment4RayItem?.Delays ?? [];
        var configMaxSplit = _config.Fragment4RayItem?.MaxSplit.NullIfEmpty() ?? "0";

        if (configLengths.Count == 0)
        {
            configLengths = ["50-100"];
        }
        if (configDelays.Count == 0)
        {
            configDelays = ["10-20"];
        }

        var maxSplit = 0;
        var parts = configMaxSplit.Split('-');
        if (parts.Length > 0 && int.TryParse(parts[0], out var ms))
        {
            maxSplit = ms;
        }

        var fragmentMask = new Mask4Ray
        {
            type = "fragment",
            settings = new MaskSettings4Ray
            {
                packets = configPackets,
                lengths = configLengths,
                delays = configDelays,
                maxSplit = maxSplit,
                // For legacy xray compatibility, remove this in the future
                length = configLengths.FirstOrDefault(),
                delay = configDelays.FirstOrDefault(),
            },
        };

        return fragmentMask;
    }

    private List<Outbounds4Ray> CloneOutbounds(List<Outbounds4Ray> outbounds)
    {
        var clonedOutbounds = new List<Outbounds4Ray>();
        foreach (var outbound in outbounds)
        {
            var clonedOutbound = JsonUtils.DeepCopy(outbound);
            clonedOutbounds.Add(clonedOutbound);
            if (context.CustomOutboundMap.ContainsKey(outbound))
            {
                context.CustomOutboundMap[clonedOutbound] = context.CustomOutboundMap[outbound];
            }
            // PattN: a copy of an Aether outbound is one too
            context.Aether.AddCopy(outbound, clonedOutbound);
        }
        return clonedOutbounds;
    }
}
